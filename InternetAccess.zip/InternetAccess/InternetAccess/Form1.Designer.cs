﻿namespace InternetAccess
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.yes1 = new System.Windows.Forms.Button();
            this.no1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // yes1
            // 
            this.yes1.Location = new System.Drawing.Point(214, 193);
            this.yes1.Name = "yes1";
            this.yes1.Size = new System.Drawing.Size(97, 56);
            this.yes1.TabIndex = 0;
            this.yes1.Text = "YES";
            this.yes1.UseVisualStyleBackColor = true;
            // 
            // no1
            // 
            this.no1.Location = new System.Drawing.Point(465, 193);
            this.no1.Name = "no1";
            this.no1.Size = new System.Drawing.Size(96, 56);
            this.no1.TabIndex = 1;
            this.no1.Text = "NO";
            this.no1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(283, 66);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(222, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Do you want Internet Access?";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.no1);
            this.Controls.Add(this.yes1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button yes1;
        private System.Windows.Forms.Button no1;
        private System.Windows.Forms.Label label1;
    }
}

