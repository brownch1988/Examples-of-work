﻿namespace FiveColors
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Blue = new System.Windows.Forms.Button();
            this.Green = new System.Windows.Forms.Button();
            this.Red = new System.Windows.Forms.Button();
            this.Yellow = new System.Windows.Forms.Button();
            this.Orange = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Blue
            // 
            this.Blue.Location = new System.Drawing.Point(59, 44);
            this.Blue.Name = "Blue";
            this.Blue.Size = new System.Drawing.Size(90, 60);
            this.Blue.TabIndex = 0;
            this.Blue.Text = "Blue";
            this.Blue.UseVisualStyleBackColor = true;
            // 
            // Green
            // 
            this.Green.Location = new System.Drawing.Point(59, 137);
            this.Green.Name = "Green";
            this.Green.Size = new System.Drawing.Size(90, 65);
            this.Green.TabIndex = 1;
            this.Green.Text = "Green";
            this.Green.UseVisualStyleBackColor = true;
            // 
            // Red
            // 
            this.Red.Location = new System.Drawing.Point(224, 137);
            this.Red.Name = "Red";
            this.Red.Size = new System.Drawing.Size(90, 68);
            this.Red.TabIndex = 2;
            this.Red.Text = "Red";
            this.Red.UseVisualStyleBackColor = true;
            // 
            // Yellow
            // 
            this.Yellow.Location = new System.Drawing.Point(373, 44);
            this.Yellow.Name = "Yellow";
            this.Yellow.Size = new System.Drawing.Size(88, 60);
            this.Yellow.TabIndex = 3;
            this.Yellow.Text = "Yellow";
            this.Yellow.UseVisualStyleBackColor = true;
            // 
            // Orange
            // 
            this.Orange.Location = new System.Drawing.Point(373, 137);
            this.Orange.Name = "Orange";
            this.Orange.Size = new System.Drawing.Size(88, 65);
            this.Orange.TabIndex = 4;
            this.Orange.Text = "Orange";
            this.Orange.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(546, 261);
            this.Controls.Add(this.Orange);
            this.Controls.Add(this.Yellow);
            this.Controls.Add(this.Red);
            this.Controls.Add(this.Green);
            this.Controls.Add(this.Blue);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Blue;
        private System.Windows.Forms.Button Green;
        private System.Windows.Forms.Button Red;
        private System.Windows.Forms.Button Yellow;
        private System.Windows.Forms.Button Orange;
    }
}

