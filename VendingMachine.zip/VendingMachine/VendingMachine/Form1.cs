﻿/*TANNER RODENBURG
 * 6/19/2020
 * ASSIGNMENT 3.1
 * BUGGY PROGRAM - VENDING MACHINE
 * BELLEVUE UNIVERSITY*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VendingMachine
{
    public partial class VendingForm : Form
    {
        public VendingForm()
        {
            InitializeComponent();
            PepsiRadio.Enabled = false;
            DietPepsiRadio.Enabled = false;
            MtDewRadio.Enabled = false;
            SpriteRadio.Enabled = false;
            MrPibbRadio.Enabled = false;
            CherryPepsiRadio.Enabled = false;
        }
        
        private void CardReader_Click(object sender, EventArgs e)
        {
            VendingText.Text = "Reading Card..." + Environment.NewLine;
            Thread.Sleep(1000);
            Update();
            VendingText.Text = "..." + Environment.NewLine;
            Thread.Sleep(1500);
            Update();
            Thread.Sleep(1000);
            VendingText.Text = "Card Accepted. Make Your Selection." + Environment.NewLine;
            PepsiRadio.Enabled = true;
            DietPepsiRadio.Enabled = true;
            MtDewRadio.Enabled = true;
            SpriteRadio.Enabled = true;
            MrPibbRadio.Enabled = true;
            CherryPepsiRadio.Enabled = true;
        }

        private void PepsiRadio_CheckedChanged(object sender, EventArgs e)
        {
            Update();
            VendingText.Text = "Vending..." + Environment.NewLine;
            Update();
            Thread.Sleep(2000);
            PopOutput.Text = "| Pepsi |";
            VendingText.Text = "Thank You. Come Again!" + Environment.NewLine;
        }

        private void DietPepsiRadio_CheckedChanged(object sender, EventArgs e)
        {
            Update();
            VendingText.Text = "Vending..." + Environment.NewLine;
            Update();
            Thread.Sleep(2000); ;
            PopOutput.Text = "| Diet Pepsi |";
            VendingText.Text = "Thank You. Come Again!";
        }

        private void MtDewRadio_CheckedChanged(object sender, EventArgs e)
        {
            Update();
            VendingText.Text = "Vending..." + Environment.NewLine;
            Update();
            Thread.Sleep(2000);
            PopOutput.Text = "| Mountain Dew |";
            VendingText.Text = "Thank You. Come Again!";
        }

        private void SpriteRadio_CheckedChanged(object sender, EventArgs e)
        {
            Update();
            VendingText.Text = "Vending..." + Environment.NewLine;
            Update();
            Thread.Sleep(2000);
            PopOutput.Text = "| Sprite |";
            VendingText.Text = "Thank You. Come Again!";
        }

        private void MrPibbRadio_CheckedChanged(object sender, EventArgs e)
        {
            Update();
            VendingText.Text = "Vending..." + Environment.NewLine;
            Update();
            Thread.Sleep(2000);
            PopOutput.Text = "| Mr. Pibb |";
            VendingText.Text = "Thank You. Come Again!";
        }

        private void CherryPepsiRadio_CheckedChanged(object sender, EventArgs e)
        {
            Update();
            VendingText.Text = "Vending..." + Environment.NewLine;
            Update();
            Thread.Sleep(2000);
            PopOutput.Text = "| Cherry Pepsi |" + Environment.NewLine;
            VendingText.Text = "Thank You. Come Again!" + Environment.NewLine;
        }
    }
}



