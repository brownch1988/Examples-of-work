﻿namespace VendingMachine
{
    partial class VendingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(VendingForm));
            this.VendingText = new System.Windows.Forms.Label();
            this.CardReader = new System.Windows.Forms.Button();
            this.PepsiLogo = new System.Windows.Forms.PictureBox();
            this.VendingBackdrop = new System.Windows.Forms.Label();
            this.ChangeSlot = new System.Windows.Forms.Label();
            this.PopOutput = new System.Windows.Forms.Label();
            this.PepsiRadio = new System.Windows.Forms.RadioButton();
            this.DietPepsiRadio = new System.Windows.Forms.RadioButton();
            this.SpriteRadio = new System.Windows.Forms.RadioButton();
            this.MrPibbRadio = new System.Windows.Forms.RadioButton();
            this.MtDewRadio = new System.Windows.Forms.RadioButton();
            this.CherryPepsiRadio = new System.Windows.Forms.RadioButton();
            this.PepsiPanel = new System.Windows.Forms.GroupBox();
            ((System.ComponentModel.ISupportInitialize)(this.PepsiLogo)).BeginInit();
            this.PepsiPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // VendingText
            // 
            this.VendingText.BackColor = System.Drawing.Color.Black;
            this.VendingText.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.VendingText.ForeColor = System.Drawing.Color.OrangeRed;
            this.VendingText.Location = new System.Drawing.Point(362, 149);
            this.VendingText.Name = "VendingText";
            this.VendingText.Size = new System.Drawing.Size(156, 36);
            this.VendingText.TabIndex = 10;
            this.VendingText.Text = "$1.50 For Pop";
            this.VendingText.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // CardReader
            // 
            this.CardReader.BackColor = System.Drawing.Color.GreenYellow;
            this.CardReader.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CardReader.Location = new System.Drawing.Point(392, 96);
            this.CardReader.Name = "CardReader";
            this.CardReader.Size = new System.Drawing.Size(102, 29);
            this.CardReader.TabIndex = 11;
            this.CardReader.Text = "Insert Card";
            this.CardReader.UseVisualStyleBackColor = false;
            this.CardReader.Click += new System.EventHandler(CardReader_Click);
            // 
            // PepsiLogo
            // 
            this.PepsiLogo.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PepsiLogo.BackColor = System.Drawing.SystemColors.Highlight;
            this.PepsiLogo.Image = ((System.Drawing.Image)(resources.GetObject("PepsiLogo.Image")));
            this.PepsiLogo.Location = new System.Drawing.Point(32, 28);
            this.PepsiLogo.Name = "PepsiLogo";
            this.PepsiLogo.Size = new System.Drawing.Size(300, 171);
            this.PepsiLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.PepsiLogo.TabIndex = 12;
            this.PepsiLogo.TabStop = false;
            // 
            // VendingBackdrop
            // 
            this.VendingBackdrop.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.VendingBackdrop.Location = new System.Drawing.Point(12, 9);
            this.VendingBackdrop.Name = "VendingBackdrop";
            this.VendingBackdrop.Size = new System.Drawing.Size(339, 592);
            this.VendingBackdrop.TabIndex = 13;
            // 
            // ChangeSlot
            // 
            this.ChangeSlot.BackColor = System.Drawing.Color.Black;
            this.ChangeSlot.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChangeSlot.ForeColor = System.Drawing.Color.OrangeRed;
            this.ChangeSlot.Location = new System.Drawing.Point(416, 500);
            this.ChangeSlot.Name = "ChangeSlot";
            this.ChangeSlot.Size = new System.Drawing.Size(49, 34);
            this.ChangeSlot.TabIndex = 14;
            // 
            // PopOutput
            // 
            this.PopOutput.BackColor = System.Drawing.Color.Black;
            this.PopOutput.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PopOutput.ForeColor = System.Drawing.Color.White;
            this.PopOutput.Location = new System.Drawing.Point(107, 500);
            this.PopOutput.Name = "PopOutput";
            this.PopOutput.Size = new System.Drawing.Size(156, 71);
            this.PopOutput.TabIndex = 15;
            this.PopOutput.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // PepsiRadio
            // 
            this.PepsiRadio.Appearance = System.Windows.Forms.Appearance.Button;
            this.PepsiRadio.BackColor = System.Drawing.Color.Gray;
            this.PepsiRadio.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.PepsiRadio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.PepsiRadio.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PepsiRadio.ForeColor = System.Drawing.Color.SeaShell;
            this.PepsiRadio.Location = new System.Drawing.Point(6, 16);
            this.PepsiRadio.Name = "PepsiRadio";
            this.PepsiRadio.Size = new System.Drawing.Size(154, 42);
            this.PepsiRadio.TabIndex = 0;
            this.PepsiRadio.Text = "Pepsi";
            this.PepsiRadio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.PepsiRadio.UseVisualStyleBackColor = false;
            this.PepsiRadio.CheckedChanged += new System.EventHandler(this.PepsiRadio_CheckedChanged);
            // 
            // DietPepsiRadio
            // 
            this.DietPepsiRadio.Appearance = System.Windows.Forms.Appearance.Button;
            this.DietPepsiRadio.BackColor = System.Drawing.Color.Gray;
            this.DietPepsiRadio.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DietPepsiRadio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.DietPepsiRadio.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DietPepsiRadio.ForeColor = System.Drawing.Color.SeaShell;
            this.DietPepsiRadio.Location = new System.Drawing.Point(7, 65);
            this.DietPepsiRadio.Name = "DietPepsiRadio";
            this.DietPepsiRadio.Size = new System.Drawing.Size(154, 42);
            this.DietPepsiRadio.TabIndex = 1;
            this.DietPepsiRadio.Text = "Diet Pepsi";
            this.DietPepsiRadio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.DietPepsiRadio.UseVisualStyleBackColor = false;
            this.DietPepsiRadio.CheckedChanged += new System.EventHandler(this.DietPepsiRadio_CheckedChanged);
            // 
            // SpriteRadio
            // 
            this.SpriteRadio.Appearance = System.Windows.Forms.Appearance.Button;
            this.SpriteRadio.BackColor = System.Drawing.Color.Gray;
            this.SpriteRadio.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.SpriteRadio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.SpriteRadio.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SpriteRadio.ForeColor = System.Drawing.Color.SeaShell;
            this.SpriteRadio.Location = new System.Drawing.Point(7, 161);
            this.SpriteRadio.Name = "SpriteRadio";
            this.SpriteRadio.Size = new System.Drawing.Size(154, 42);
            this.SpriteRadio.TabIndex = 3;
            this.SpriteRadio.Text = "Sprite";
            this.SpriteRadio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.SpriteRadio.UseVisualStyleBackColor = false;
            this.SpriteRadio.CheckedChanged += new System.EventHandler(this.SpriteRadio_CheckedChanged);
            // 
            // MrPibbRadio
            // 
            this.MrPibbRadio.Appearance = System.Windows.Forms.Appearance.Button;
            this.MrPibbRadio.BackColor = System.Drawing.Color.Gray;
            this.MrPibbRadio.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MrPibbRadio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.MrPibbRadio.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MrPibbRadio.ForeColor = System.Drawing.Color.SeaShell;
            this.MrPibbRadio.Location = new System.Drawing.Point(7, 209);
            this.MrPibbRadio.Name = "MrPibbRadio";
            this.MrPibbRadio.Size = new System.Drawing.Size(154, 42);
            this.MrPibbRadio.TabIndex = 4;
            this.MrPibbRadio.Text = "Mr. Pibb";
            this.MrPibbRadio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MrPibbRadio.UseVisualStyleBackColor = false;
            this.MrPibbRadio.CheckedChanged += new System.EventHandler(this.MrPibbRadio_CheckedChanged);
            // 
            // MtDewRadio
            // 
            this.MtDewRadio.Appearance = System.Windows.Forms.Appearance.Button;
            this.MtDewRadio.BackColor = System.Drawing.Color.Gray;
            this.MtDewRadio.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MtDewRadio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.MtDewRadio.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MtDewRadio.ForeColor = System.Drawing.Color.SeaShell;
            this.MtDewRadio.Location = new System.Drawing.Point(7, 113);
            this.MtDewRadio.Name = "MtDewRadio";
            this.MtDewRadio.Size = new System.Drawing.Size(154, 42);
            this.MtDewRadio.TabIndex = 6;
            this.MtDewRadio.Text = "Mt. Dew";
            this.MtDewRadio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.MtDewRadio.UseVisualStyleBackColor = false;
            this.MtDewRadio.CheckedChanged += new System.EventHandler(this.MtDewRadio_CheckedChanged);
            // 
            // CherryPepsiRadio
            // 
            this.CherryPepsiRadio.Appearance = System.Windows.Forms.Appearance.Button;
            this.CherryPepsiRadio.BackColor = System.Drawing.Color.Gray;
            this.CherryPepsiRadio.CheckAlign = System.Drawing.ContentAlignment.TopCenter;
            this.CherryPepsiRadio.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Red;
            this.CherryPepsiRadio.Font = new System.Drawing.Font("Calibri", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CherryPepsiRadio.ForeColor = System.Drawing.Color.SeaShell;
            this.CherryPepsiRadio.Location = new System.Drawing.Point(7, 257);
            this.CherryPepsiRadio.Name = "CherryPepsiRadio";
            this.CherryPepsiRadio.Size = new System.Drawing.Size(154, 42);
            this.CherryPepsiRadio.TabIndex = 7;
            this.CherryPepsiRadio.Text = "Cherry Pepsi";
            this.CherryPepsiRadio.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.CherryPepsiRadio.UseVisualStyleBackColor = false;
            this.CherryPepsiRadio.CheckedChanged += new System.EventHandler(this.CherryPepsiRadio_CheckedChanged);
            // 
            // PepsiPanel
            // 
            this.PepsiPanel.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.PepsiPanel.BackColor = System.Drawing.Color.Black;
            this.PepsiPanel.Controls.Add(this.PepsiRadio);
            this.PepsiPanel.Controls.Add(this.CherryPepsiRadio);
            this.PepsiPanel.Controls.Add(this.MtDewRadio);
            this.PepsiPanel.Controls.Add(this.MrPibbRadio);
            this.PepsiPanel.Controls.Add(this.SpriteRadio);
            this.PepsiPanel.Controls.Add(this.DietPepsiRadio);
            this.PepsiPanel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.PepsiPanel.Location = new System.Drawing.Point(357, 188);
            this.PepsiPanel.Name = "PepsiPanel";
            this.PepsiPanel.Size = new System.Drawing.Size(168, 309);
            this.PepsiPanel.TabIndex = 16;
            this.PepsiPanel.TabStop = false;
            // 
            // VendingForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.HotTrack;
            this.ClientSize = new System.Drawing.Size(526, 612);
            this.Controls.Add(this.PepsiPanel);
            this.Controls.Add(this.PopOutput);
            this.Controls.Add(this.ChangeSlot);
            this.Controls.Add(this.PepsiLogo);
            this.Controls.Add(this.CardReader);
            this.Controls.Add(this.VendingText);
            this.Controls.Add(this.VendingBackdrop);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "VendingForm";
            this.Text = "Pepsi Machine";
            ((System.ComponentModel.ISupportInitialize)(this.PepsiLogo)).EndInit();
            this.PepsiPanel.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Label VendingText;
        private System.Windows.Forms.Button CardReader;
        private System.Windows.Forms.PictureBox PepsiLogo;
        private System.Windows.Forms.Label VendingBackdrop;
        private System.Windows.Forms.Label ChangeSlot;
        private System.Windows.Forms.Label PopOutput;
        private System.Windows.Forms.RadioButton PepsiRadio;
        private System.Windows.Forms.RadioButton DietPepsiRadio;
        private System.Windows.Forms.RadioButton SpriteRadio;
        private System.Windows.Forms.RadioButton MrPibbRadio;
        private System.Windows.Forms.RadioButton MtDewRadio;
        private System.Windows.Forms.RadioButton CherryPepsiRadio;
        private System.Windows.Forms.GroupBox PepsiPanel;
    }
}

