﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectRaisesGUI
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Button_Click1(object sender, EventArgs e)
        {
            if (CurrentSalary.Text == string.Empty || Convert.ToInt32(CurrentSalary.Text) < 0)
            {
                MessageBox.Show("Please Enter a Valid Value");
            }
            else
            {
                label3.Text = Convert.ToString(Convert.ToDouble(CurrentSalary.Text) * 1.04);
            }
        }
    }
}
